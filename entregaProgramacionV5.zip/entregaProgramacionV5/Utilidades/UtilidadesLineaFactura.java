package Utilidades;

public class UtilidadesLineaFactura {

}
