package Modelos;

public enum tipoProducto {
    alimentacion,
    bebida,
    drogueria;


}
