package Modelos;

import java.util.List;

public enum TipoContrato {
    PRACTICAS,
    TEMPORAL,
    OBRAYSERVICIO,
    INDEFINIDO
}
