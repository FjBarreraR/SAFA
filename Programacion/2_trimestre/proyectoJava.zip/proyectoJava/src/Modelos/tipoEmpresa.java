package Modelos;

public enum tipoEmpresa {
    PYME,
    STARTUP,
    NACIONAL,
    MULTINACIONAL
}
