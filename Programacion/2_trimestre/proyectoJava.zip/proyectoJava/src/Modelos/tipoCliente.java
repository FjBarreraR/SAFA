package Modelos;

public enum tipoCliente {
    particular,
    empresa;
}
