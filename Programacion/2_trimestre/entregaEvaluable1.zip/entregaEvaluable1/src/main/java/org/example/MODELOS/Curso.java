package org.example.MODELOS;

public enum Curso {
    PRIMARIA, SECUNDARIA, BACH, CICLOS
}
