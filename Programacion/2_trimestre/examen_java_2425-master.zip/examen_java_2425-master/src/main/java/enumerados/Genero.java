package enumerados;

public enum Genero {

    ACCION, AVENTURA, TERROR, DRAMA, COMEDIA, ROMANTICO, THRILLER, ANIMACION;
}
