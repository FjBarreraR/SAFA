package utilidades;


import modelos.*;

import java.time.Duration;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UtilidadesCine {



    public static List<Cine> ejercicio1(List<Cine> cines){
        return new ArrayList<>();
    }



    public static Map<Sala, Integer> ejercicio2(Cine cine){
        return new HashMap<>();
    }


    public static Pelicula ejercicio3(Cine cine){
        return null;
    }



    public static Map<Proyeccion,Long> ejercicio4(Sala sala){
        return new HashMap<>();
    }



    public static Double ejercicio5(Cine cine){
        return null;
    }



    public static InformeProyeccion ejercicio6(Proyeccion proyeccion){
        return null;
    }








}
